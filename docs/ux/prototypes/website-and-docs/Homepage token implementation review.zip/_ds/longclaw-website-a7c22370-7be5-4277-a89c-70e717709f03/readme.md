# LongClaw Design System

LongClaw is a **local-first, plain-text issue tracker for AI-native startups**. Tickets live as plain-text files in your repo — no separate database, no lock-in, agent-friendly by design. Taglines seen in brand materials: "Local-first issue tracking for AI-native startups", "Plain-text issue tracking for AI-native teams", "Tickets live as plain-text files in your repo".

The brand mark is a geometric **owl** — chevron ear-tufts over an open ring face with a diamond beak. Flat vector only.

## Sources
- 10 uploaded brand PNGs in `uploads/` (Aug 13 2026): logo lockup sheet, brand sheet (color tokens, type, theme suggestions, do/don't), favicon system, macOS app icon sheet, standalone marks, tagline banners.
- No codebase, Figma, or font binaries were provided. Components below are a standard authored set (no source inventory existed).

## Products
One surface in scope: the **LongClaw marketing website** (`ui_kits/website/`).

## CONTENT FUNDAMENTALS
- **Voice**: plain, technical, confident. Short declarative sentences. "Tickets live as plain-text files in your repo" — states a fact, no hype adjectives.
- **Person**: second person ("your repo", "your terminal"). Product speaks as a tool, not a companion.
- **Casing**: sentence case for headlines and body. UPPERCASE reserved for small mono eyebrow labels (brand sheets use `WORDMARK DIRECTION`, `APPROVED COLORS` style section labels in mono/wide tracking).
- **Vocabulary**: developer-native — repo, plain-text, local-first, CLI, agent, diff. Never marketing fluff ("revolutionary", "supercharge").
- **Emoji**: never. Brand don'ts explicitly ban cartoon expressions; text stays typographic.
- **Technical text** (commands, file paths, tokens, data) is always set in IBM Plex Mono.

## VISUAL FOUNDATIONS
- **Color**: warm paper + ochre + near-black. Light theme: `#FAF6EF` page, `#FFFFFF` cards, `#17150F` ink, `#B45F06` accent (hover `#D97706`). Dark theme ("Dock Night"): `#14120D` page, `#1A1812` cards, `#FAF6EF` ink, `#E89B2F` accent. Explicit don'ts: **no blue-violet, no coral**.
- **Two actors, two hues**: ochre = human, green = agent (`--agent` #12946A light / #2FBF8F dark, `--agent-text`, `--agent-wash`). Green marks agent activity — ticket excerpts, code annotations, the two-actor homepage section — and stays constant across surfaces. Same hue family as the app's design system; the two must read as siblings.
- **Theming**: every semantic token is defined in both appearances. Dark applies via `[data-theme="dark"]` or system-matched (`prefers-color-scheme: dark` unless the page sets `data-theme="light"`).
- **Accessibility**: raw `#B45F06` fails AA as body text on paper (4.26:1) — use `--accent-text` (#96500A, 5.6:1) for ochre running text/links; reserve raw ochre for large marks, buttons (white-on-ochre passes at 4.59:1), and washes. Agent green as text uses `--agent-text` (#0E7A57 light, 4.9:1). Dark-side accents pass at ~8:1.
- **Type**: IBM Plex Sans (400–700) for everything; IBM Plex Mono for code/data/labels. Tight tracking on large headings; wide-tracked uppercase mono for eyebrows. Marketing heroes may use `--text-display-lg` (72px); product UI stays ≤ `--text-2xl`. (Recursive Sans/Mono was the rejected Option B.)
- **Flatness**: brand rule — **no gradients, no shadows**. Depth comes from surface steps (paper → white card) and 1px warm borders (`--border` #E7DFD2 light / #2B2820 dark).
- **Corners**: moderate rounding — 8px controls/inputs, 12px cards, ~20px app-icon containers, pill for chips/badges. No circular badges or enclosures around the mark.
- **Spacing**: 4px grid; generous whitespace like the brand sheets (airy sections, thin hairline dividers).
- **Backgrounds**: solid fills only. No imagery, textures, patterns, or illustration — the sheets are pure type + mark on paper.
- **Motion**: minimal and quick — 120–180ms ease-out fades/color transitions. No bounces or slides.
- **Hover**: accent shifts one step lighter (#B45F06 → #D97706); neutral surfaces darken slightly. **Press**: one step darker, no scale/shrink.
- **Focus**: 2px ochre ring, offset 2px.
- **Imagery color vibe**: n/a — brand uses no photography; keep it typographic and warm-neutral.
- **Transparency/blur**: not used anywhere in brand materials; avoid.

## ICONOGRAPHY
- Only brand-owned graphic: the owl mark (`assets/longclaw-mark-ochre.png`, `assets/longclaw-mark-amber.png` — transparent, keyed from provided PNGs; no SVG master was supplied).
- No product icon set was provided. **Substitution**: use [Lucide](https://lucide.dev) from CDN (1.5–2px stroke, geometric, flat) — it matches the mark's angular geometry. Flagged: replace if LongClaw adopts an official set.
- No icon font, no emoji, no unicode-as-icon. Mono glyphs (`>`, `$`) may appear inside terminal/CLI contexts only (brand sheet shows `> run` chip).
- Logo usage: mark height = 1.05× wordmark cap height; clear space = diamond (beak) height on all sides; never skew, stretch, recolor outside approved colors, or enclose in circles.

## Intentional additions (not in brand sheets)
- `--danger` / `--success` status colors (warm-compatible) — needed for form validation and badges.
- Derived warm neutrals (`--lc-sand-*`, `--lc-stone-*`) interpolated between paper and ink for borders/muted text.

## Index
- `styles.css` → imports `tokens/` (fonts, colors, typography, spacing, effects)
- `assets/` — transparent owl marks, lockup banners, original brand sheets
- `guidelines/` — specimen cards (colors incl. agent accent, type, spacing, radii, brand, two-actor sample in both appearances)
- `components/actions/` — Button, IconButton
- `components/forms/` — Input, Select, Checkbox, Radio, Switch
- `components/display/` — Card, Badge, Tag
- `components/navigation/` — Tabs
- `components/feedback/` — Dialog, Toast, Tooltip
- `ui_kits/website/` — marketing site recreation (index.html + section JSX)
- `SKILL.md` — agent skill entry point
