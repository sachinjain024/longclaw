/* @ds-bundle: {"format":4,"namespace":"LongClawDesignSystem_a7c223","components":[{"name":"Button","sourcePath":"components/actions/Button.jsx"},{"name":"IconButton","sourcePath":"components/actions/IconButton.jsx"},{"name":"Badge","sourcePath":"components/display/Badge.jsx"},{"name":"Card","sourcePath":"components/display/Card.jsx"},{"name":"Tag","sourcePath":"components/display/Tag.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/actions/Button.jsx":"288d715cf0c4","components/actions/IconButton.jsx":"72a6306410d1","components/display/Badge.jsx":"b33f148bbd51","components/display/Card.jsx":"da010cafaeb1","components/display/Tag.jsx":"50dfe2e9731d","components/feedback/Dialog.jsx":"a9b82691adfe","components/feedback/Toast.jsx":"d53c6cb96207","components/feedback/Tooltip.jsx":"cfc2bcc1ea26","components/forms/Checkbox.jsx":"85fd9235aeed","components/forms/Input.jsx":"48ea2f9e413f","components/forms/Radio.jsx":"18819abd4309","components/forms/Select.jsx":"f10b43b9ab2c","components/forms/Switch.jsx":"af519d2d3cf3","components/navigation/Tabs.jsx":"f0b44e581d9a","ui_kits/website/Header.jsx":"aba3ba0470f0","ui_kits/website/Hero.jsx":"9d5bdbc69d5a","ui_kits/website/Sections.jsx":"59023e8279a3"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.LongClawDesignSystem_a7c223 = window.LongClawDesignSystem_a7c223 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/actions/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const sizes = {
  sm: {
    padding: '6px 12px',
    fontSize: '13px',
    height: '32px'
  },
  md: {
    padding: '8px 16px',
    fontSize: '15px',
    height: '40px'
  },
  lg: {
    padding: '10px 22px',
    fontSize: '16px',
    height: '48px'
  }
};
const variants = {
  primary: {
    background: 'var(--accent)',
    color: 'var(--accent-contrast)',
    border: '1px solid transparent',
    hoverBg: 'var(--accent-hover)'
  },
  secondary: {
    background: 'var(--surface-card)',
    color: 'var(--text-body)',
    border: '1px solid var(--border-strong)',
    hoverBg: 'var(--surface-sunken)'
  },
  ghost: {
    background: 'transparent',
    color: 'var(--accent)',
    border: '1px solid transparent',
    hoverBg: 'var(--surface-sunken)'
  },
  danger: {
    background: 'var(--danger)',
    color: '#fff',
    border: '1px solid transparent',
    hoverBg: '#9E3623'
  }
};
function Button({
  variant = 'primary',
  size = 'md',
  disabled = false,
  iconLeft = null,
  children,
  style,
  ...rest
}) {
  const v = variants[variant] || variants.primary,
    s = sizes[size] || sizes.md;
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", _extends({
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: '8px',
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      cursor: disabled ? 'not-allowed' : 'pointer',
      borderRadius: 'var(--radius-md)',
      transition: 'background var(--duration-fast) var(--ease-out),color var(--duration-fast) var(--ease-out)',
      background: hover && !disabled ? v.hoverBg : v.background,
      color: v.color,
      border: v.border,
      opacity: disabled ? 0.45 : 1,
      ...s,
      ...style
    }
  }, rest), iconLeft, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/Button.jsx", error: String((e && e.message) || e) }); }

// components/actions/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function IconButton({
  label,
  size = 'md',
  variant = 'secondary',
  disabled = false,
  children,
  style,
  ...rest
}) {
  const px = size === 'sm' ? 32 : size === 'lg' ? 48 : 40;
  const v = {
    primary: {
      background: 'var(--accent)',
      color: 'var(--accent-contrast)',
      border: '1px solid transparent',
      hoverBg: 'var(--accent-hover)'
    },
    secondary: {
      background: 'var(--surface-card)',
      color: 'var(--text-body)',
      border: '1px solid var(--border-strong)',
      hoverBg: 'var(--surface-sunken)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--text-muted)',
      border: '1px solid transparent',
      hoverBg: 'var(--surface-sunken)'
    }
  }[variant];
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", _extends({
    "aria-label": label,
    title: label,
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: px,
      height: px,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 'var(--radius-md)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      transition: 'background var(--duration-fast) var(--ease-out)',
      background: hover && !disabled ? v.hoverBg : v.background,
      color: v.color,
      border: v.border,
      opacity: disabled ? 0.45 : 1,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/display/Badge.jsx
try { (() => {
const tones = {
  neutral: {
    bg: 'var(--surface-sunken)',
    fg: 'var(--text-muted)',
    bd: 'var(--border)'
  },
  accent: {
    bg: 'color-mix(in srgb, var(--accent) 12%, transparent)',
    fg: 'var(--accent)',
    bd: 'color-mix(in srgb, var(--accent) 30%, transparent)'
  },
  success: {
    bg: 'var(--success-surface)',
    fg: 'var(--success)',
    bd: 'transparent'
  },
  danger: {
    bg: 'var(--danger-surface)',
    fg: 'var(--danger)',
    bd: 'transparent'
  },
  inverse: {
    bg: 'var(--lc-ink-900)',
    fg: 'var(--lc-paper-50)',
    bd: 'transparent'
  }
};
function Badge({
  tone = 'neutral',
  mono = false,
  children,
  style
}) {
  const t = tones[tone] || tones.neutral;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '5px',
      padding: '2px 9px',
      borderRadius: '999px',
      fontSize: '12px',
      fontWeight: 500,
      fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)',
      background: t.bg,
      color: t.fg,
      border: `1px solid ${t.bd}`,
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/display/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Card({
  title,
  subtitle,
  footer,
  padding = '20px',
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--surface-card)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-lg)',
      fontFamily: 'var(--font-sans)',
      color: 'var(--text-body)',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
      ...style
    }
  }, rest), (title || subtitle) && /*#__PURE__*/React.createElement("div", {
    style: {
      padding,
      paddingBottom: 0
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '17px',
      fontWeight: 600,
      letterSpacing: '-0.01em'
    }
  }, title), subtitle && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '13px',
      color: 'var(--text-muted)',
      marginTop: '2px'
    }
  }, subtitle)), /*#__PURE__*/React.createElement("div", {
    style: {
      padding,
      flex: 1
    }
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 20px',
      borderTop: '1px solid var(--border)',
      background: 'var(--surface-sunken)',
      fontSize: '13px',
      color: 'var(--text-muted)'
    }
  }, footer));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Card.jsx", error: String((e && e.message) || e) }); }

// components/display/Tag.jsx
try { (() => {
function Tag({
  onRemove,
  children,
  style
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '6px',
      padding: '3px 10px',
      borderRadius: 'var(--radius-sm)',
      fontSize: '13px',
      fontFamily: 'var(--font-mono)',
      background: 'var(--surface-sunken)',
      color: 'var(--text-body)',
      border: '1px solid var(--border)',
      ...style
    }
  }, children, onRemove && /*#__PURE__*/React.createElement("button", {
    onClick: onRemove,
    "aria-label": "Remove",
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      border: 'none',
      background: 'none',
      padding: 0,
      cursor: 'pointer',
      display: 'inline-flex',
      color: hover ? 'var(--danger)' : 'var(--text-faint)'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 12 12",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M3 3l6 6M9 3l-6 6",
    stroke: "currentColor",
    strokeWidth: "1.5",
    strokeLinecap: "round"
  }))));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function Dialog({
  open,
  title,
  children,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  danger = false,
  onConfirm,
  onCancel
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    onClick: onCancel,
    style: {
      position: 'fixed',
      inset: 0,
      background: 'rgba(23,21,15,0.45)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 100,
      fontFamily: 'var(--font-sans)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-modal": "true",
    onClick: e => e.stopPropagation(),
    style: {
      background: 'var(--surface-card)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-lg)',
      width: 'min(440px, calc(100vw - 48px))',
      padding: '24px',
      color: 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '18px',
      fontWeight: 600,
      letterSpacing: '-0.01em'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '14px',
      lineHeight: 1.55,
      color: 'var(--text-muted)',
      marginTop: '8px'
    }
  }, children), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: '10px',
      marginTop: '22px'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "secondary",
    onClick: onCancel
  }, cancelLabel), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: danger ? 'danger' : 'primary',
    onClick: onConfirm
  }, confirmLabel))));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function Toast({
  tone = 'neutral',
  title,
  children,
  onDismiss,
  style
}) {
  const border = tone === 'success' ? 'var(--success)' : tone === 'danger' ? 'var(--danger)' : tone === 'accent' ? 'var(--accent)' : 'var(--border-strong)';
  return /*#__PURE__*/React.createElement("div", {
    role: "status",
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: '12px',
      background: 'var(--lc-coal-900)',
      color: 'var(--lc-paper-50)',
      borderRadius: 'var(--radius-md)',
      border: `1px solid ${border}`,
      padding: '12px 14px',
      maxWidth: '380px',
      fontFamily: 'var(--font-sans)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '14px',
      fontWeight: 600
    }
  }, title), children && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '13px',
      opacity: .8,
      marginTop: title ? '2px' : 0
    }
  }, children)), onDismiss && /*#__PURE__*/React.createElement("button", {
    onClick: onDismiss,
    "aria-label": "Dismiss",
    style: {
      border: 'none',
      background: 'none',
      padding: '2px',
      cursor: 'pointer',
      color: 'inherit',
      opacity: .6
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 14 14",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M3.5 3.5l7 7M10.5 3.5l-7 7",
    stroke: "currentColor",
    strokeWidth: "1.5",
    strokeLinecap: "round"
  }))));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function Tooltip({
  label,
  side = 'top',
  children
}) {
  const [show, setShow] = React.useState(false);
  const pos = side === 'bottom' ? {
    top: 'calc(100% + 6px)'
  } : {
    bottom: 'calc(100% + 6px)'
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'inline-flex'
    },
    onMouseEnter: () => setShow(true),
    onMouseLeave: () => setShow(false),
    onFocus: () => setShow(true),
    onBlur: () => setShow(false)
  }, children, show && /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: 'absolute',
      left: '50%',
      transform: 'translateX(-50%)',
      ...pos,
      background: 'var(--lc-ink-900)',
      color: 'var(--lc-paper-50)',
      fontSize: '12px',
      fontFamily: 'var(--font-sans)',
      padding: '4px 9px',
      borderRadius: 'var(--radius-sm)',
      whiteSpace: 'nowrap',
      zIndex: 50,
      pointerEvents: 'none'
    }
  }, label));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  label,
  checked,
  onChange,
  disabled = false,
  style
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '10px',
      fontFamily: 'var(--font-sans)',
      fontSize: '15px',
      color: 'var(--text-body)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      width: '18px',
      height: '18px',
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: checked,
    onChange: onChange,
    disabled: disabled,
    style: {
      position: 'absolute',
      inset: 0,
      opacity: 0,
      margin: 0,
      cursor: 'inherit'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 'var(--radius-sm)',
      background: checked ? 'var(--accent)' : 'var(--surface-card)',
      border: `1px solid ${checked ? 'var(--accent)' : 'var(--border-strong)'}`,
      transition: 'background var(--duration-fast) var(--ease-out)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, checked && /*#__PURE__*/React.createElement("svg", {
    width: "11",
    height: "11",
    viewBox: "0 0 11 11",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M2 5.8L4.3 8L9 3",
    stroke: "var(--accent-contrast)",
    strokeWidth: "1.8",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })))), label);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  label,
  hint,
  error,
  mono = false,
  prefix = null,
  style,
  inputStyle,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      fontFamily: 'var(--font-sans)',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '13px',
      fontWeight: 600,
      color: 'var(--text-body)'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      background: 'var(--surface-card)',
      border: `1px solid ${error ? 'var(--danger)' : focus ? 'var(--focus-ring)' : 'var(--border-strong)'}`,
      boxShadow: focus ? `0 0 0 2px ${error ? 'var(--danger-surface)' : 'color-mix(in srgb, var(--focus-ring) 25%, transparent)'}` : 'none',
      borderRadius: 'var(--radius-md)',
      transition: 'border-color var(--duration-fast) var(--ease-out)'
    }
  }, prefix && /*#__PURE__*/React.createElement("span", {
    style: {
      paddingLeft: '12px',
      color: 'var(--text-faint)',
      fontFamily: 'var(--font-mono)',
      fontSize: '14px'
    }
  }, prefix), /*#__PURE__*/React.createElement("input", _extends({
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      minWidth: 0,
      padding: '9px 12px',
      fontSize: '15px',
      border: 'none',
      outline: 'none',
      background: 'transparent',
      color: 'var(--text-body)',
      fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)',
      ...inputStyle
    }
  }, rest))), error ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '12px',
      color: 'var(--danger)'
    }
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '12px',
      color: 'var(--text-muted)'
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function Radio({
  label,
  name,
  value,
  checked,
  onChange,
  disabled = false,
  style
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '10px',
      fontFamily: 'var(--font-sans)',
      fontSize: '15px',
      color: 'var(--text-body)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      width: '18px',
      height: '18px',
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "radio",
    name: name,
    value: value,
    checked: checked,
    onChange: onChange,
    disabled: disabled,
    style: {
      position: 'absolute',
      inset: 0,
      opacity: 0,
      margin: 0,
      cursor: 'inherit'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: '50%',
      background: 'var(--surface-card)',
      border: `${checked ? '5px' : '1px'} solid ${checked ? 'var(--accent)' : 'var(--border-strong)'}`,
      boxSizing: 'border-box',
      transition: 'border var(--duration-fast) var(--ease-out)'
    }
  })), label);
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  label,
  options = [],
  value,
  onChange,
  disabled = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      fontFamily: 'var(--font-sans)',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '13px',
      fontWeight: 600,
      color: 'var(--text-body)'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'block'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    value: value,
    onChange: onChange,
    disabled: disabled,
    style: {
      width: '100%',
      appearance: 'none',
      padding: '9px 34px 9px 12px',
      fontSize: '15px',
      fontFamily: 'var(--font-sans)',
      color: 'var(--text-body)',
      background: 'var(--surface-card)',
      border: '1px solid var(--border-strong)',
      borderRadius: 'var(--radius-md)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1
    }
  }, rest), options.map(o => typeof o === 'string' ? /*#__PURE__*/React.createElement("option", {
    key: o,
    value: o
  }, o) : /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label))), /*#__PURE__*/React.createElement("svg", {
    style: {
      position: 'absolute',
      right: '12px',
      top: '50%',
      transform: 'translateY(-50%)',
      pointerEvents: 'none'
    },
    width: "12",
    height: "12",
    viewBox: "0 0 12 12",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M2.5 4.5L6 8l3.5-3.5",
    stroke: "var(--text-muted)",
    strokeWidth: "1.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function Switch({
  label,
  checked,
  onChange,
  disabled = false,
  style
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '10px',
      fontFamily: 'var(--font-sans)',
      fontSize: '15px',
      color: 'var(--text-body)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      width: '36px',
      height: '20px',
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    role: "switch",
    checked: checked,
    onChange: onChange,
    disabled: disabled,
    style: {
      position: 'absolute',
      inset: 0,
      opacity: 0,
      margin: 0,
      cursor: 'inherit'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: '999px',
      background: checked ? 'var(--accent)' : 'var(--border-strong)',
      transition: 'background var(--duration-base) var(--ease-out)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: '2px',
      left: checked ? '18px' : '2px',
      width: '16px',
      height: '16px',
      borderRadius: '50%',
      background: '#fff',
      transition: 'left var(--duration-base) var(--ease-out)'
    }
  })), label);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function Tabs({
  tabs = [],
  active,
  onChange,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    role: "tablist",
    style: {
      display: 'flex',
      gap: '4px',
      borderBottom: '1px solid var(--border)',
      fontFamily: 'var(--font-sans)',
      ...style
    }
  }, tabs.map(t => {
    const id = typeof t === 'string' ? t : t.id;
    const label = typeof t === 'string' ? t : t.label;
    const is = id === active;
    return /*#__PURE__*/React.createElement(TabBtn, {
      key: id,
      is: is,
      onClick: () => onChange && onChange(id)
    }, label);
  }));
}
function TabBtn({
  is,
  onClick,
  children
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    role: "tab",
    "aria-selected": is,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      padding: '10px 14px',
      fontSize: '14px',
      fontFamily: 'inherit',
      fontWeight: is ? 600 : 400,
      color: is ? 'var(--text-body)' : hover ? 'var(--text-body)' : 'var(--text-muted)',
      boxShadow: is ? 'inset 0 -2px 0 var(--accent)' : 'none',
      transition: 'color var(--duration-fast) var(--ease-out)'
    }
  }, children);
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Header.jsx
try { (() => {
const {
  Button
} = window.LongClawDesignSystem_a7c223;
function Header({
  theme,
  onToggleTheme
}) {
  const [active, setActive] = React.useState('Product');
  const links = ['Product', 'Docs', 'Pricing', 'Changelog'];
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 40,
      background: 'var(--surface-base)',
      borderBottom: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 var(--container-pad)',
      height: 64,
      display: 'flex',
      alignItems: 'center',
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      textDecoration: 'none',
      color: 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: theme === 'dark' ? '../../assets/longclaw-mark-amber.png' : '../../assets/longclaw-mark-ochre.png',
    alt: "LongClaw",
    style: {
      height: 28
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 19,
      fontWeight: 600,
      letterSpacing: '-0.01em'
    }
  }, "LongClaw")), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 4,
      flex: 1
    }
  }, links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#",
    onClick: e => {
      e.preventDefault();
      setActive(l);
    },
    style: {
      padding: '8px 12px',
      borderRadius: 'var(--radius-md)',
      fontSize: 14,
      textDecoration: 'none',
      fontWeight: active === l ? 600 : 400,
      color: active === l ? 'var(--text-body)' : 'var(--text-muted)',
      background: active === l ? 'var(--surface-sunken)' : 'transparent'
    }
  }, l))), /*#__PURE__*/React.createElement("button", {
    onClick: onToggleTheme,
    "aria-label": "Toggle theme",
    style: {
      border: '1px solid var(--border-strong)',
      background: 'var(--surface-card)',
      color: 'var(--text-muted)',
      borderRadius: 'var(--radius-md)',
      width: 36,
      height: 36,
      cursor: 'pointer',
      fontFamily: 'var(--font-mono)',
      fontSize: 13
    }
  }, theme === 'dark' ? '☾' : '☀'), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      fontSize: 14,
      color: 'var(--text-muted)',
      textDecoration: 'none'
    }
  }, "Sign in"), /*#__PURE__*/React.createElement(Button, {
    size: "sm"
  }, "Get started")));
}
window.LCHeader = Header;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Header.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Hero.jsx
try { (() => {
const {
  Button,
  Badge
} = window.LongClawDesignSystem_a7c223;
function Hero() {
  const [copied, setCopied] = React.useState(false);
  const cmd = 'curl -fsSL longclaw.dev/install | sh';
  return /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '88px var(--container-pad) 72px',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'center',
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "accent",
    mono: true
  }, "v1.4 \u2014 agent hooks")), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 'var(--text-display)',
      lineHeight: 'var(--leading-tight)',
      letterSpacing: 'var(--tracking-tight)',
      fontWeight: 700,
      margin: 0,
      color: 'var(--text-body)'
    }
  }, "Tickets live as plain-text", /*#__PURE__*/React.createElement("br", null), "files in your repo"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-lg)',
      lineHeight: 'var(--leading-normal)',
      color: 'var(--text-muted)',
      maxWidth: 560,
      margin: '20px auto 0'
    }
  }, "Local-first issue tracking for AI-native startups. No database, no lock-in \u2014 branch it, diff it, grep it, hand it to an agent."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      justifyContent: 'center',
      marginTop: 32
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "lg"
  }, "Get started free"), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    variant: "secondary"
  }, "Read the docs")), /*#__PURE__*/React.createElement("button", {
    onClick: () => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    },
    style: {
      marginTop: 28,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 12,
      background: 'var(--lc-coal-900)',
      color: 'var(--lc-paper-50)',
      border: '1px solid var(--border-strong)',
      borderRadius: 'var(--radius-md)',
      padding: '10px 16px',
      cursor: 'pointer',
      fontFamily: 'var(--font-mono)',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--lc-ochre-400)'
    }
  }, "$"), " ", cmd, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: copied ? 'var(--lc-ochre-400)' : '#A99C88',
      minWidth: 44,
      textAlign: 'right'
    }
  }, copied ? 'copied' : 'copy')));
}
window.LCHero = Hero;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Sections.jsx
try { (() => {
const {
  Button,
  Card,
  Badge,
  Tag,
  Tabs
} = window.LongClawDesignSystem_a7c223;
function Terminal() {
  const [tab, setTab] = React.useState('cli');
  const lines = {
    cli: [['$', 'longclaw new "Fix flaky auth test" -p high -t auth,ci'], ['', 'created .claw/issues/0042-fix-flaky-auth-test.md'], ['$', 'longclaw ls --open'], ['', '#0042  high    Fix flaky auth test          auth ci'], ['', '#0041  normal  Debounce sidebar search      ui'], ['', '#0038  low     Update onboarding copy       docs']],
    file: [['', '---'], ['', 'id: 0042'], ['', 'status: open'], ['', 'priority: high'], ['', 'tags: [auth, ci]'], ['', '---'], ['', '## Fix flaky auth test'], ['', '`test_refresh_token` fails ~1/20 runs on CI.']],
    agent: [['$', 'claude "pick up the highest-priority open ticket"'], ['', 'Reading .claw/issues/0042-fix-flaky-auth-test.md…'], ['', 'Reproduced locally after 14 runs. Root cause: clock skew'], ['', 'in token expiry check. Patch + ticket update committed.']]
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 760,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    tabs: [{
      id: 'cli',
      label: 'CLI'
    }, {
      id: 'file',
      label: 'The ticket file'
    }, {
      id: 'agent',
      label: 'With an agent'
    }],
    active: tab,
    onChange: setTab
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--lc-coal-950)',
      border: '1px solid var(--border-strong)',
      borderRadius: 'var(--radius-lg)',
      marginTop: 16,
      padding: '18px 20px',
      textAlign: 'left',
      fontFamily: 'var(--font-mono)',
      fontSize: 13,
      lineHeight: 1.75,
      color: 'var(--lc-paper-50)',
      minHeight: 170
    }
  }, lines[tab].map((l, i) => /*#__PURE__*/React.createElement("div", {
    key: tab + i
  }, l[0] && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--lc-ochre-400)'
    }
  }, l[0], " "), /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: l[0] ? 1 : .75
    }
  }, l[1])))));
}
function Features() {
  const items = [{
    t: 'Local-first',
    d: 'Every ticket is a markdown file in .claw/. Works offline; syncs when you push. Your tracker is exactly as available as your repo.'
  }, {
    t: 'Agent-native',
    d: 'Plain text is the interface agents already speak. Point Claude at a ticket file — no API keys, no browser automation.'
  }, {
    t: 'Zero lock-in',
    d: 'No database to export, no vendor to leave. Delete the binary and your tickets are still just files under version control.'
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--surface-card)',
      borderTop: '1px solid var(--border)',
      borderBottom: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '72px var(--container-pad)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      letterSpacing: 'var(--tracking-wide)',
      textTransform: 'uppercase',
      color: 'var(--accent)',
      fontWeight: 500,
      textAlign: 'center'
    }
  }, "Why plain text"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 'var(--text-2xl)',
      fontWeight: 600,
      letterSpacing: 'var(--tracking-tight)',
      textAlign: 'center',
      margin: '10px 0 40px',
      color: 'var(--text-body)'
    }
  }, "Your issue tracker, in your repo"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 20
    }
  }, items.map(it => /*#__PURE__*/React.createElement("div", {
    key: it.t,
    style: {
      background: 'var(--surface-base)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-lg)',
      padding: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 17,
      fontWeight: 600,
      color: 'var(--text-body)'
    }
  }, it.t), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      lineHeight: 1.6,
      color: 'var(--text-muted)',
      margin: '8px 0 0'
    }
  }, it.d)))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 64
    }
  }, /*#__PURE__*/React.createElement(Terminal, null))));
}
function CTA() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--lc-coal-950)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '72px var(--container-pad)',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/longclaw-mark-amber.png",
    alt: "",
    style: {
      height: 56,
      marginBottom: 20
    }
  }), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 'var(--text-2xl)',
      fontWeight: 600,
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--lc-paper-50)',
      margin: 0
    }
  }, "Track your first ticket in 60 seconds"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15,
      color: '#A99C88',
      margin: '12px 0 28px'
    }
  }, "Free for individuals and open source. No account needed to start."), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    style: {
      background: 'var(--lc-ochre-400)',
      color: '#17150F'
    }
  }, "Install LongClaw")));
}
function Footer({
  theme
}) {
  const cols = [{
    h: 'Product',
    l: ['Overview', 'CLI', 'Agent hooks', 'Changelog']
  }, {
    h: 'Resources',
    l: ['Docs', 'Ticket format', 'GitHub', 'Status']
  }, {
    h: 'Company',
    l: ['About', 'Blog', 'Contact']
  }];
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--surface-base)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '56px var(--container-pad) 40px',
      display: 'grid',
      gridTemplateColumns: '2fr 1fr 1fr 1fr',
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: theme === 'dark' ? '../../assets/longclaw-mark-amber.png' : '../../assets/longclaw-mark-ochre.png',
    alt: "",
    style: {
      height: 24
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 16,
      fontWeight: 600,
      color: 'var(--text-body)'
    }
  }, "LongClaw")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)',
      marginTop: 10,
      maxWidth: 240
    }
  }, "Plain-text issue tracking for AI-native teams.")), cols.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.h
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      letterSpacing: 'var(--tracking-wide)',
      textTransform: 'uppercase',
      color: 'var(--text-faint)',
      marginBottom: 12
    }
  }, c.h), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, c.l.map(x => /*#__PURE__*/React.createElement("a", {
    key: x,
    href: "#",
    style: {
      fontSize: 14,
      color: 'var(--text-muted)',
      textDecoration: 'none'
    }
  }, x)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '16px var(--container-pad)',
      fontSize: 12,
      color: 'var(--text-faint)',
      fontFamily: 'var(--font-mono)'
    }
  }, "\xA9 2026 LongClaw")));
}
Object.assign(window, {
  LCFeatures: Features,
  LCCTA: CTA,
  LCFooter: Footer
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Sections.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
